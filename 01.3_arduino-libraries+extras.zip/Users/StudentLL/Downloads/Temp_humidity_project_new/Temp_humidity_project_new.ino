#include <LiquidCrystal.h>
#include "DFRobot_DHT20.h" //use the specific sensor information
LiquidCrystal lcd(12,11,5,4,3,2);
DFRobot_DHT20 dht20;

void setup() {
  dht20.begin();// put your setup code here, to run once
  lcd.begin(16,2);//LCD screen is 16 characters by 2 lines

}

void loop() {
  float h = dht20.getHumidity()*100; //value for humidity
  float t = dht20.getTemperature(); //Value for temperature
  t = t * 9 / 5 + 32; //change reading from Celsius to Fahrenheit
  if (isnan(t) || isnan(h)) { //check that DHT sensor is working 
    lcd.setCursor(0,0);
    lcd.print ("Failed to read"); // If DHT is not working, display this
    lcd.setCursor(0,1);
     lcd.print ("from sensor");
  } else { //Otherwise sho the readings on the screen
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print("Humidity: ");
    lcd.print(h);
    lcd.print("%");
    lcd.setCursor(0,1);
    lcd.print("Temp:");
    lcd.print(t);
    lcd.print("f");
  }
  delay(500);
}
